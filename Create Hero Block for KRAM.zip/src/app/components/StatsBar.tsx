import { Users, Package, TrendingUp } from 'lucide-react';
import { motion } from 'motion/react';

export function StatsBar() {
  const stats = [
    { icon: <Users className="w-4 h-4" />, value: '50K+', label: 'Активних користувачів' },
    { icon: <Package className="w-4 h-4" />, value: '1.2M', label: 'Успішних угод' },
    { icon: <TrendingUp className="w-4 h-4" />, value: '98%', label: 'Рейтинг задоволення' },
  ];

  return (
    <div className="flex gap-6">
      {stats.map((stat, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 + index * 0.1 }}
          className="flex items-center gap-3"
        >
          <div className="w-10 h-10 rounded-lg bg-muted/50 flex items-center justify-center text-[#3B82F6]">
            {stat.icon}
          </div>
          <div>
            <div className="text-lg font-bold text-foreground">{stat.value}</div>
            <div className="text-xs text-muted-foreground">{stat.label}</div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
