import { useState, useEffect } from 'react';
import { Clock, TrendingUp, Shield, CheckCircle, Eye } from 'lucide-react';
import { LineChart, Line, Area, AreaChart, ResponsiveContainer } from 'recharts';
import { motion } from 'motion/react';

const bidData = [
  { value: 8500 },
  { value: 8600 },
  { value: 8700 },
  { value: 8850 },
  { value: 8900 },
  { value: 9100 },
  { value: 9200 },
  { value: 9400 },
  { value: 9500 },
  { value: 9750 },
  { value: 9800 },
  { value: 10000 },
  { value: 10200 },
];

export function LiveLotCard() {
  const [timeLeft, setTimeLeft] = useState({ hours: 2, minutes: 34, seconds: 12 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { hours: prev.hours, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.3 }}
      className="relative bg-card rounded-2xl p-6 border border-border overflow-hidden shadow-2xl shadow-[#B6FF3B]/10 hover:shadow-[#B6FF3B]/20 hover:border-[#B6FF3B]/30 cursor-pointer"
    >
      <div className="absolute top-3 right-3 flex items-center gap-2">
        <span className="text-xs font-semibold text-[#B6FF3B]">LIVE</span>
        <motion.div
          animate={{ scale: [1, 1.2, 1], opacity: [1, 0.7, 1] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="w-3 h-3 bg-[#B6FF3B] rounded-full shadow-lg shadow-[#B6FF3B]/50"
        />
      </div>

      <div className="flex gap-4 mb-4">
        <div className="w-24 h-24 bg-muted rounded-xl overflow-hidden flex-shrink-0">
          <img
            src="https://images.unsplash.com/photo-1680775335339-5b8dd5d03b21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
            alt="iPhone 14 Pro Max"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold mb-1">iPhone 14 Pro Max 256GB</h3>
          <div className="flex items-center gap-2 mb-2">
            <Shield className="w-4 h-4 text-[#B6FF3B]" />
            <span className="text-sm text-muted-foreground">Верифікований продавець</span>
            <CheckCircle className="w-3 h-3 text-[#B6FF3B]" />
          </div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <span className="text-[#B6FF3B] font-semibold">9.8</span>
            <span>/10 рейтинг довіри</span>
          </div>
        </div>
      </div>

      <div className="mb-4 h-20 bg-muted/30 rounded-lg p-2">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={bidData}>
            <defs>
              <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#B6FF3B" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#B6FF3B" stopOpacity={0} />
              </linearGradient>
            </defs>
            <Area
              type="monotone"
              dataKey="value"
              stroke="#B6FF3B"
              strokeWidth={2}
              fill="url(#colorValue)"
              dot={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-between mb-4 bg-gradient-to-r from-[#B6FF3B]/5 to-transparent rounded-lg p-4 -mx-2">
        <div>
          <div className="text-xs text-muted-foreground mb-1">Поточна ставка</div>
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
            className="text-3xl font-bold text-[#B6FF3B]"
          >
            ₴10,200
          </motion.div>
        </div>
        <div className="flex items-center gap-2 text-[#B6FF3B] bg-[#B6FF3B]/10 px-3 py-2 rounded-lg">
          <TrendingUp className="w-5 h-5" />
          <span className="text-sm font-semibold">+20%</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="flex items-center gap-2 bg-muted/50 rounded-lg p-3">
          <Clock className="w-4 h-4 text-[#3B82F6]" />
          <div className="flex gap-1 text-sm">
            <span className="font-mono font-bold">{String(timeLeft.hours).padStart(2, '0')}</span>
            <span>:</span>
            <span className="font-mono font-bold">{String(timeLeft.minutes).padStart(2, '0')}</span>
            <span>:</span>
            <span className="font-mono font-bold">{String(timeLeft.seconds).padStart(2, '0')}</span>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-muted/50 rounded-lg p-3">
          <Eye className="w-4 h-4 text-[#3B82F6]" />
          <span className="text-sm font-semibold">247 учасників</span>
        </div>
      </div>

      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="w-full bg-[#B6FF3B] text-black font-semibold py-3 rounded-xl hover:bg-[#a5ee2a] transition-all shadow-lg shadow-[#B6FF3B]/30 hover:shadow-[#B6FF3B]/50"
      >
        Зробити ставку
      </motion.button>
    </motion.div>
  );
}
