import { motion } from 'motion/react';

export function Logo() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="absolute top-8 left-8 flex items-center gap-2"
    >
      <div className="w-10 h-10 bg-gradient-to-br from-[#B6FF3B] to-[#3B82F6] rounded-xl flex items-center justify-center shadow-lg shadow-[#B6FF3B]/30">
        <span className="text-black font-bold text-xl">K</span>
      </div>
      <span className="text-2xl font-bold tracking-tight">KRAM</span>
    </motion.div>
  );
}
