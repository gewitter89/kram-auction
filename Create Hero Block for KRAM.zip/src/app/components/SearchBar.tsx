import { Search, DollarSign, Truck, CheckCircle, Clock } from 'lucide-react';
import { motion } from 'motion/react';

export function SearchBar() {
  return (
    <div className="w-full">
      <div className="relative mb-4">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          type="text"
          placeholder="Знайти лот..."
          className="w-full bg-input-background border border-border rounded-xl pl-12 pr-4 py-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#B6FF3B] focus:border-[#B6FF3B] transition-all"
        />
      </div>

      <div className="flex flex-wrap gap-2">
        <FilterChip icon={<DollarSign className="w-4 h-4" />} label="Ціна" />
        <FilterChip icon={<Truck className="w-4 h-4" />} label="Доставка" />
        <FilterChip icon={<CheckCircle className="w-4 h-4" />} label="Верифіковані" active />
        <FilterChip icon={<Clock className="w-4 h-4" />} label="Закінчується сьогодні" />
      </div>
    </div>
  );
}

interface FilterChipProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
}

function FilterChip({ icon, label, active = false }: FilterChipProps) {
  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-all ${
        active
          ? 'bg-[#B6FF3B] text-black border-[#B6FF3B] font-semibold'
          : 'bg-muted/30 text-foreground border-border hover:border-[#3B82F6]'
      }`}
    >
      {icon}
      <span className="text-sm">{label}</span>
    </motion.button>
  );
}
