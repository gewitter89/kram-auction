import { motion } from 'motion/react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { LiveLotCard } from './components/LiveLotCard';
import { SearchBar } from './components/SearchBar';
import { StatsBar } from './components/StatsBar';
import { Logo } from './components/Logo';

export default function App() {
  return (
    <div className="w-full min-h-screen bg-background flex items-center justify-center p-8">
      <div className="w-[1024px] h-[1024px] relative">
        <Logo />
        <div className="grid grid-cols-2 gap-8 h-full">
          {/* Left Column */}
          <div className="flex flex-col justify-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="inline-flex items-center gap-2 bg-muted/50 border border-[#B6FF3B]/20 rounded-full px-4 py-2 mb-6"
              >
                <Sparkles className="w-4 h-4 text-[#B6FF3B]" />
                <span className="text-sm font-medium text-foreground">0% комісії для всіх</span>
              </motion.div>

              <h1 className="text-6xl font-bold mb-6 leading-[1.1] tracking-tight">
                Торгуйся.{' '}
                <span className="text-[#B6FF3B] drop-shadow-[0_0_30px_rgba(182,255,59,0.3)]">Вигравай.</span>{' '}
                <span className="text-[#3B82F6] drop-shadow-[0_0_30px_rgba(59,130,246,0.3)]">Домовляйся напряму.</span>
              </h1>

              <p className="text-xl text-muted-foreground mb-8 leading-relaxed max-w-xl">
                KRAM — перша платформа аукціонів з прямими угодами між покупцями та продавцями.
                <span className="text-foreground font-semibold"> Без комісій</span>, з прозорими ставками та гарантією якості.
              </p>

              <div className="flex gap-4 mb-10">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex items-center gap-2 bg-[#B6FF3B] text-black font-semibold px-8 py-4 rounded-xl hover:bg-[#a5ee2a] transition-all shadow-lg shadow-[#B6FF3B]/30 hover:shadow-[#B6FF3B]/50"
                >
                  Переглянути лоти
                  <ArrowRight className="w-5 h-5" />
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex items-center gap-2 bg-muted border border-border text-foreground font-semibold px-8 py-4 rounded-xl hover:border-[#3B82F6] hover:bg-muted/80 transition-all"
                >
                  Створити лот
                </motion.button>
              </div>

              <SearchBar />

              <div className="mt-10 pt-8 border-t border-border/50">
                <StatsBar />
              </div>
            </motion.div>
          </div>

          {/* Right Column */}
          <div className="flex items-center justify-center">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="w-full max-w-md"
            >
              <LiveLotCard />
            </motion.div>
          </div>
        </div>

        {/* Background decorative elements */}
        <motion.div
          animate={{ scale: [1, 1.1, 1], opacity: [0.05, 0.08, 0.05] }}
          transition={{ repeat: Infinity, duration: 8, ease: "easeInOut" }}
          className="absolute top-0 left-0 w-[500px] h-[500px] bg-[#B6FF3B] opacity-5 blur-[120px] rounded-full -z-10"
        />
        <motion.div
          animate={{ scale: [1, 1.15, 1], opacity: [0.05, 0.08, 0.05] }}
          transition={{ repeat: Infinity, duration: 10, ease: "easeInOut" }}
          className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-[#3B82F6] opacity-5 blur-[120px] rounded-full -z-10"
        />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-[#B6FF3B] opacity-[0.02] blur-[100px] rounded-full -z-10" />
      </div>
    </div>
  );
}