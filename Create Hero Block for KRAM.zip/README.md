
  # Create Hero Block for KRAM

  This is a code bundle for Create Hero Block for KRAM. The original project is available at https://www.figma.com/design/eAT0fMEkXjk82XZKFyookl/Create-Hero-Block-for-KRAM.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  